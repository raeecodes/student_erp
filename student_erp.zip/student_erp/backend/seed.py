# seed.py
from pymongo import MongoClient
from werkzeug.security import generate_password_hash
from config import MONGO_URI
from datetime import datetime

client = MongoClient(MONGO_URI)
db = client["student_erp"]
students_col = db["students"]
marks_col = db["marks"]

student = {
    "student_id": "S1001",
    "name": "Rachit Nainwal",
    "semester": "3",
    "course": "B.Tech",
    "branch": "CSE",
    "email": "rachitnainwal@gmail.com",
    "mobile": "4384393443",

    "password_hash": generate_password_hash("Rachit123")
}
students_col.update_one({"student_id": student["student_id"]}, {"$set": student}, upsert=True)

marks = {
    "student_id": "S1001",
    "subjects": [
        {"name": "Mathematics-III", "marks": 78},
        {"name": "Data Structures", "marks": 65},
        {"name": "Operating Systems", "marks": 58},
        {"name": "Digital Logic", "marks": 36},
        {"name": "Computer Networks", "marks": 42}
    ],
    "last_updated": datetime.utcnow()
}
marks_col.update_one({"student_id": marks["student_id"]}, {"$set": marks}, upsert=True)

print("✓ Seed created successfully")
print("Login: S1001   Password: Rachit123")
