import io
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_file, jsonify
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from pymongo import MongoClient
from gridfs import GridFS
from bson.objectid import ObjectId

from config import MONGO_URI, SECRET_KEY, MAX_CONTENT_LENGTH, ALLOWED_EXTENSIONS

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

client = MongoClient(MONGO_URI)
db = client["student_erp"]
students_col = db["students"]
attendance_col = db["attendance"]
marks_col = db["marks"]
fs = GridFS(db, collection="uploads")

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if "student_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapped

@app.context_processor
def inject_year():
    return {"current_year": datetime.utcnow().year}

@app.route("/profile/pic/<student_id>")
def profile_pic(student_id):
    user = students_col.find_one({"student_id": student_id})
    if not user or "profile_pic" not in user:
        return send_file("static/img/default.png")  # fallback default

    try:
        grid_out = fs.get(ObjectId(user["profile_pic"]))
        return send_file(
            io.BytesIO(grid_out.read()),
            mimetype=grid_out.content_type
        )
    except:
        return send_file("static/img/default.png")


@app.route("/")
def root():
    if "student_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        student_id = request.form.get("student_id", "").strip()
        password = request.form.get("password", "")
        student = students_col.find_one({"student_id": student_id})
        if student and student.get("password_hash") and check_password_hash(student["password_hash"], password):
            session["student_id"] = student_id
            session["name"] = student.get("name", "")
            flash("Logged in successfully.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid Student ID or Password", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out", "info")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    student = students_col.find_one({"student_id": session["student_id"]})
    return render_template("dashboard.html", student=student)

@app.route("/attendance")
@login_required
def attendance():
    return render_template("attendance.html")

@app.route("/attendance/mark", methods=["POST"])
@login_required
def attendance_mark():
    student_id = session["student_id"]
    course = request.form.get("course", "General").strip()
    status = request.form.get("status", "present")
    date_str = request.form.get("date")
    try:
        if date_str:
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
        else:
            date_obj = datetime.utcnow().date()
    except Exception:
        date_obj = datetime.utcnow().date()
   
    existing = attendance_col.find_one({"student_id": student_id, "course": course, "date": date_obj.isoformat()})
    if existing:
        flash("Attendance already exists for that date and course.", "warning")
    else:
        attendance_col.insert_one({
            "student_id": student_id,
            "course": course,
            "date": date_obj.isoformat(),
            "status": status,
            "marked_at": datetime.utcnow()
        })
        flash("Attendance marked.", "success")
    return redirect(url_for("attendance"))

@app.route("/attendance/view")
@login_required
def attendance_view():
    docs = list(attendance_col.find({"student_id": session["student_id"]}).sort("date", -1))
    return render_template("view_attendance.html", attendance=docs)

@app.route("/assignment")
@login_required
def assignment():
    return render_template("assignment.html")

@app.route("/assignment/upload", methods=["POST"])
@login_required
def assignment_upload():
    if "file" not in request.files:
        flash("No file part in the form.", "danger")
        return redirect(url_for("assignment"))
    file = request.files["file"]
    if file.filename == "":
        flash("No file selected.", "danger")
        return redirect(url_for("assignment"))
    if not allowed_file(file.filename):
        flash("Only PDF files are allowed.", "danger")
        return redirect(url_for("assignment"))
    filename = secure_filename(file.filename)
    data = file.read()
    meta = {
    "student_id": session["student_id"],
    "type": "assignment",
    "upload_time": datetime.utcnow(),
    "original_filename": filename
}

    file_id = fs.put(data, filename=filename, metadata=meta, contentType="application/pdf")
    flash("Assignment uploaded successfully.", "success")
    return redirect(url_for("assignment"))

@app.route("/assignment/list")
@login_required
def assignment_list():
    files_cursor = fs.find({
    "metadata.student_id": session["student_id"],
    "metadata.type": "assignment"
}).sort("uploadDate", -1)
    files = [{"_id": str(f._id), "filename": f.filename, "date": f.upload_date.isoformat()} for f in files_cursor]
    return jsonify({"files": files})

@app.route("/assignment/download/<file_id>")
@login_required
def assignment_download(file_id):
    try:
        grid_out = fs.get(ObjectId(file_id))
        return send_file(io.BytesIO(grid_out.read()), download_name=grid_out.filename, as_attachment=True, mimetype=grid_out.content_type)
    except Exception:
        flash("File not found.", "danger")
        return redirect(url_for("assignment"))
    

@app.route("/results")
@login_required
def results():
    return render_template("results.html")

@app.route("/results/view")
@login_required
def results_view():
    rec = marks_col.find_one({"student_id": session["student_id"]})
    subjects = rec.get("subjects", []) if rec else []
    return render_template("view_result.html", subjects=subjects)

@app.route("/results/backpapers")
@login_required
def results_backpapers():
    rec = marks_col.find_one({"student_id": session["student_id"]})
    subjects = rec.get("subjects", []) if rec else []
    backpapers = [s for s in subjects if int(s.get("marks", 0)) < 40]
    return jsonify({"backpapers": backpapers})

@app.route("/_create_student", methods=["POST"])
def _create_student():
    data = request.json or {}
    sid = data.get("student_id")
    name = data.get("name", "Test Student")
    pw = data.get("password", "Password123")
    if not sid:
        return {"error": "student_id required"}, 400
    students_col.update_one({"student_id": sid}, {"$set": {
        "student_id": sid,
        "name": name,
        "semester": data.get("semester","1"),
        "course": data.get("course","B.Tech"),
        "branch": data.get("branch","CSE"),
        "email": data.get("email",""),
        "password_hash": generate_password_hash(pw)
    }}, upsert=True)
    return {"ok": True}

if __name__ == "__main__":
    app.run(debug=True)
