console.log('Main JS loaded');

(function(){
  const search = document.getElementById('topSearch');
  if(search){
    search.addEventListener('keydown', (e)=>{
      if(e.key==='Enter'){
        e.preventDefault();
        alert('Search is not wired in demo');
      }
    });
  }
})();
